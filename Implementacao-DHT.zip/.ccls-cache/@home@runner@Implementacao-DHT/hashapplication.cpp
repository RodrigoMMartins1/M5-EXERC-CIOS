#include <iostream>
#include "hash.h"

using namespace std;

int main(){
  Hash loginHash(10);
  int imeis[7] = {
    12704, 31300, 1234,
    49001, 52202, 65606,
    91234};
  string emails[7] = {
    "pedro@email.com", "raul@email.com", "paulo@email.com",
    "carlos@email.com", "lucas@email.com", "maria@email.com",
    "samanta@email.com"};

  
  // Caso de Teste 1:
  cout << "Teste de caso 1, Verifica a inserção de logins:" << endl;
  for (int i = 0; i < 7; i++) {
    Login login = Login(imeis[i], emails[i]);
    loginHash.insertItem(login);
  }
  cout << "Tabela de hash após inserção de 7 logins:" << endl;
  loginHash.print();

  // Caso de Teste 2:
  cout << "Teste de caso 2, verifica a existência/recuperação de um login:" << endl;
  int imeiPesquisado = 49001;
  Login loginPesquisado = Login(imeiPesquisado, "");
  bool found;
  loginHash.retrieveItem(loginPesquisado, found);
  //Retorna found true ou false
  if (found) {
    cout << "Login encontrado: " << loginPesquisado.getEmail() << endl;
  } else {
    cout << "Login não encontrado." << endl;
  }

  // Caso de Teste 3:
  cout << "Caso de teste 3, Verifica exclusão de imei:" << endl;
  int imeiExcluido = 12704;
  Login loginExcluido = Login(imeiExcluido, "");
  loginHash.deleteItem(loginExcluido);
  cout << "Tabela de hash após exclusão do login com IMEI " << imeiExcluido << ":" << endl;
loginHash.print();

  // Caso de Teste 4:
  cout << "Caso de teste 4, Verifica se a tabela ta cheia" << endl;
  if (loginHash.isFull()) {
    cout << "A tabela está cheia." << endl;
  } else {
    cout << "A tabela não está cheia." << endl;
  }

  // Caso de Teste 5:
  cout << "Teste de caso 5, verifica o tamanho da tabela" << endl;
  cout << "Número de itens na tabela: " << loginHash.getLength() << endl;

  return 0;
}

#include "login.h"

class Hash {
public:
Hash(int max_items = 100);
~Hash();
bool isFull() const;
int getLength() const;

void retrieveItem(Login& login, bool& found);
void insertItem(Login login);
void deleteItem(Login login);
void print();
private:
int getHash(Login login);
int max_items;
int length;
Login* structure;
};
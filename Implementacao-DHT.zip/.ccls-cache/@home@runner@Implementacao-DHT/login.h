#include <iostream>
using namespace std;

class Login{
private :
int imei;
std::string email;
public:
Login();
Login(int imei, std::string email);
string getEmail() const;
int getImei() const;
};
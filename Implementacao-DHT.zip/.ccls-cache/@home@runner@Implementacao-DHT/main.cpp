#include <iostream>
using namespace std;

class Login { // Criando classe login
private: // Modificador private, para permitir apenas membros da classe o acesso
  int imei;          // Criando varável IMEI
  std::string email; // variavel email
public:              // Modificador public, qualquer membro tem acesso
public:
  Login();
  Login(int imei, std::string email);
  std::string getEmail() const;
  int getImei() const;
};
Login::Login() {
  this->imei = -1; //
  this->email = "";
};
Login::Login(int imei, std::string email) {
  this->imei = imei;
  this->email = email;
}

std::string Login::getEmail() const { return email; }
int Login::getImei() const { return imei; }

class Hash {
public:
  Hash(int max_items = 100);
  ~Hash();
  bool isFull() const;
  int getLength() const;

  void retrieveItem(Login &login, bool &found);
  void insertItem(Login login);
  void deleteItem(Login login);
  void print();

private:
  int getHash(Login login);
  int max_items;
  int length;
  Login *structure;
};

Hash::Hash(int max) {
  length = 0;
  max_items = max;
  structure = new Login[max_items];
}

Hash::~Hash() { delete[] structure; }

bool Hash::isFull() const { return (length == max_items); }

int Hash::getLength() const { return length; }

void Hash::retrieveItem(Login &login, bool &found) {
  int location = getHash(login);
  Login aux = structure[location];
  if (login.getImei() != aux.getImei()) {
    found = false;
  } else {
    found = true;
    login = aux;
  }
}

void Hash::insertItem(Login login) {
  int location = getHash(login);
  structure[location] = login;
}

int main() {
  Hash loginHash(10);
  int imeis[7] = {12704, 31300, 1234, 49001, 52202, 65606, 91234};
  string names[7] = {"Pedro", "Raul",  "Paulo",  "Carlos",
                     "Lucas", "Maria", "Samanta"};

  for (int i = 0; i < 7; i++) {
    Login login = Login(imeis[i], names[i]);
    loginHash.insertItem(login);
  }
  loginHash.print();
  cout << "------------------------------" << endl;

  Login login(12704, "");
  bool found = false;
  loginHash.retrieveItem(login, found);
  cout << login.getEmail() << " -> " << found << endl;

  cout << "------------------------------" << endl;
  loginHash.deleteItem(login);
  loginHash.print();
  cout << "Fim" << endl;
}

#include "hash.h"
#include <iostream>
using namespace std;

Hash::Hash(int max) {
length = 0;
max_items = max;
structure = new Login[max_items];
}

Hash::~Hash(){
delete [] structure;
}

bool Hash::isFull() const {
return (length == max_items);
}

int Hash::getLength() const {
return length;
}

void Hash::retrieveItem(Login& login, bool& found) {
int location = getHash(login);
Login aux = structure[location];
if (login.getImei() != aux.getImei()) {
found = false;
} else {
found = true;
login = aux;
}
}

void Hash::insertItem(Login login) {
int location = getHash(login);
structure[location] = login;
length++;
}

void Hash::deleteItem(Login login) {
int location = getHash(login);
structure[location] = Login();
length--;
}

void Hash::print() {
for (int i = 0; i < max_items; i++) {
cout << i << ":" << structure[i].getImei() << ", " << structure[i].getEmail() << endl;
}
}

int Hash::getHash(Login login){
return login.getImei() % max_items;
}
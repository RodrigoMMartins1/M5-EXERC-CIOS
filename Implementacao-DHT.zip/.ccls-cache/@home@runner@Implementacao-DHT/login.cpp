#include "login.h"

Login::Login(){
this->imei = -1;
this->email = "";
};
Login::Login(int imei, std::string email){
this->imei = imei;
this->email = email;
}
string Login::getEmail() const {
return email;
}
int Login::getImei() const{
return imei;
}